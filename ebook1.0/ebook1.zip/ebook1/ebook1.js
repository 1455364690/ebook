/* Created by sunjiahui on 3/10/16.
 */
function toTop1(){
    var goToTop=document.getElementById('jiantou');
    var imgw=parseInt(jiantou.style.width);
    var imgh=parseInt(jiantou.style.height);
    goToTop.style.width=imgw+30+'px';
    goToTop.style.height=imgh+30+'px';
}
function toTop2(){
    var goToTop=document.getElementById('jiantou');
    var imgw=parseInt(jiantou.style.width);
    var imgh=parseInt(jiantou.style.height);
    goToTop.style.width=imgw-30+'px';
    goToTop.style.height=imgh-30+'px';
}
function ch2() {
    var next = document.getElementById('image');
    if (next.src = 'g5.jpg')
    {
        next.src='g1.jpg'
    }
    else if(next.src = 'g1.jpg')
    {
        next.src='g2.jpg'
    }
    else if (next.src ='g2.jpg')
    {
        next.src='g3.jpg'
    }
    else if(next.src = 'g3.jpg')
    {
        next.src='g4.jpg'
    }
    else if(next.src ='g4.jpg')
    {
        next.src='g5.jpg'
    }

}
function ch3(){
    var bor=document.getElementById('image');
    var borWidth=parseInt(bor.style.borderWidth);
    bor.style.borderWidth=borWidth+5+'px';
}
function ch4(){
    var bor=document.getElementById('image');
    var borWidth=parseInt(bor.style.borderWidth);
    bor.style.borderWidth=borWidth-5+'px';
}

/*function change(){
    var next = document.getElementById('image');
    switch (next.src)
    {
        case '5.jpg': next.src='1.jpg';break;
        case '1.jpg': next.src='2.jpg';break;
        case '2.jpg': next.src='3.jpg';break;
        case '3.jpg': next.src='4.jpg';break;
        case '4.jpg': next.src='5.jpg';break;
    }
}
*/